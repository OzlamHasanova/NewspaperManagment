package com.example.newspapermanagment.enums;

public enum UserRole {
    ADMIN
}
